// Skills, grouped into five categories per src/data/README.md conventions.
// `proficiency` (0-100) is a rough signal for sorting/visual bars, derived from
// resume-stated experience length where available — treat as approximate.

export const skills = [
  // ---- Technical ----
  { id: 'skill-python', name: 'Python', category: 'Technical', proficiency: 90, months_experience: 18, order: 0 },
  { id: 'skill-html-css', name: 'HTML & CSS', category: 'Technical', proficiency: 85, months_experience: 16, order: 1 },
  { id: 'skill-javascript', name: 'JavaScript', category: 'Technical', proficiency: 80, months_experience: 14, order: 2 },
  { id: 'skill-typescript', name: 'TypeScript', category: 'Technical', proficiency: 78, months_experience: 14, order: 3 },
  { id: 'skill-react', name: 'React', category: 'Technical', proficiency: 78, months_experience: 14, order: 4 },
  { id: 'skill-nodejs', name: 'Node.js', category: 'Technical', proficiency: 75, months_experience: 14, order: 5 },
  { id: 'skill-cpp', name: 'C++', category: 'Technical', proficiency: 55, months_experience: 5, order: 6 },
  { id: 'skill-swift', name: 'Swift (iOS)', category: 'Technical', proficiency: 35, months_experience: 3, order: 7 },
  { id: 'skill-git-github', name: 'Git & GitHub', category: 'Technical', proficiency: 80, order: 8 },
  { id: 'skill-rest-apis', name: 'REST APIs', category: 'Technical', proficiency: 70, order: 9 },
  { id: 'skill-hardware-integration', name: 'Hardware / Software Integration', category: 'Technical', proficiency: 65, order: 10 },
  { id: 'skill-databases', name: 'Databases (SQL, Amazon RDS)', category: 'Technical', proficiency: 55, order: 11 },

  // ---- Design ----
  { id: 'skill-figma', name: 'Figma', category: 'Design', proficiency: 70, order: 0 },
  { id: 'skill-canva', name: 'Canva', category: 'Design', proficiency: 90, order: 1 },
  { id: 'skill-webflow', name: 'Webflow', category: 'Design', proficiency: 65, order: 2 },
  { id: 'skill-ui-ux-design', name: 'UI/UX Design', category: 'Design', proficiency: 75, order: 3 },
  { id: 'skill-graphic-design', name: 'Graphic Design', category: 'Design', proficiency: 85, order: 4 },
  { id: 'skill-branding', name: 'Branding & Visual Identity', category: 'Design', proficiency: 85, order: 5 },
  { id: 'skill-visual-communication', name: 'Visual Communication', category: 'Design', proficiency: 85, order: 6 },

  // ---- Marketing ----
  { id: 'skill-social-media-management', name: 'Social Media Management', category: 'Marketing', proficiency: 90, order: 0 },
  { id: 'skill-campaign-strategy', name: 'Campaign Strategy', category: 'Marketing', proficiency: 85, order: 1 },
  { id: 'skill-content-creation', name: 'Content Creation', category: 'Marketing', proficiency: 88, order: 2 },
  { id: 'skill-analytics', name: 'Engagement Analytics', category: 'Marketing', proficiency: 75, order: 3 },
  { id: 'skill-copywriting', name: 'Copywriting', category: 'Marketing', proficiency: 75, order: 4 },
  { id: 'skill-brand-management', name: 'Brand Management', category: 'Marketing', proficiency: 82, order: 5 },
  { id: 'skill-email-marketing', name: 'Email Marketing & Outreach', category: 'Marketing', proficiency: 78, order: 6 },
  { id: 'skill-sponsorship-outreach', name: 'Sponsorship & Partnership Outreach', category: 'Marketing', proficiency: 75, order: 7 },

  // ---- Creative ----
  { id: 'skill-photography', name: 'Photography', category: 'Creative', proficiency: 85, order: 0 },
  { id: 'skill-videography', name: 'Videography', category: 'Creative', proficiency: 80, order: 1 },
  { id: 'skill-video-editing', name: 'Video Editing', category: 'Creative', proficiency: 75, order: 2 },
  { id: 'skill-storytelling', name: 'Storytelling', category: 'Creative', proficiency: 75, order: 3 },

  // ---- Leadership ----
  { id: 'skill-team-management', name: 'Team Management', category: 'Leadership', proficiency: 88, order: 0 },
  { id: 'skill-event-planning', name: 'Event Planning', category: 'Leadership', proficiency: 88, order: 1 },
  { id: 'skill-public-speaking', name: 'Public Speaking', category: 'Leadership', proficiency: 78, order: 2 },
  { id: 'skill-project-management', name: 'Project Management', category: 'Leadership', proficiency: 82, order: 3 },
  { id: 'skill-community-building', name: 'Community Building', category: 'Leadership', proficiency: 85, order: 4 },
  { id: 'skill-board-governance', name: 'Board Governance', category: 'Leadership', proficiency: 70, order: 5 },
  { id: 'skill-mentorship', name: 'Mentorship', category: 'Leadership', proficiency: 80, order: 6 },
];

export default skills;
